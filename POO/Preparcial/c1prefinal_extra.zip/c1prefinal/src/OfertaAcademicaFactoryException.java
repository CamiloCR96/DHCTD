public class OfertaAcademicaFactoryException extends Exception{

    public OfertaAcademicaFactoryException(String message) {
        super(message);
    }
}
